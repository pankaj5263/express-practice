import express from 'express';
import env from 'dotenv';
import db from './db/db.js';
import UserRouter from './src/users/routes.js';
import AuthRouter from './src/authentication/routes.js';
import verifyToken from './src/middlewares/auth-middleware.js';
import TaskRouter from './src/tasks/routes.js';
const app = express();
env.config();
db();
app.use(express.json());
// app.use(express.urlencoded({ extended: true }));
app.get('/', function(req, res) {
    res.send('<h1>Welcome! to the ne express server</h1>');
})
app.use('/api/users/',verifyToken, UserRouter);
app.use('/api/auth',AuthRouter);
app.use('/api/tasks/',TaskRouter);
app.listen(process.env.EXPRESS_PORT,function(err) {
    if (err) {
        throw err;
    }
    console.log("Server running on port " + process.env.EXPRESS_PORT);
});

