import mongoose from "mongoose";
const Schema = mongoose.Schema;

const userSchema = new mongoose.Schema({
    _id: {
      type: Schema.Types.ObjectId,
      required: true
    },
    _name: {
      type: String,
      required: true
    },
    _userId: {
      type: Number,
      required: true
    }
  });


const userModel = mongoose.model('User', userSchema);

export default userModel;