import userModel from "./model.js";
export default class UsersController {
    async getAllUsers(req, res, next) {
        console.log(await userModel.find());
        const users = await userModel.find();
        return res.json(users)
    }
}