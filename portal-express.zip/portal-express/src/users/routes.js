import express from 'express';
import UsersController from './controller.js';
const router = express.Router();

const users = new  UsersController();

router.get('/', users.getAllUsers);

export default router;