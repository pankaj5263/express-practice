import userModel from "./modal.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
export default class Authentication {
  async registerUser(req, res, next) {
    try {
      const findUser = await userModel.findOne({ _email: req.body.email });
      if (findUser) {
        return res.status(400).send("User already registered");
      }
      const hashedPassword = await bcrypt.hash(req.body.password, 10);
      const user = {
        _name: req.body.name,
        _userId: req.body.userId,
        _email: req.body.email,
        _password: hashedPassword
      };
      const newUser = new userModel(user);
      await newUser.save();
      res.status(201).send("User registered successfully");
    } catch (error) {
      console.error("Error registering user:", error);
      res.status(500).send("Internal Server Error");
    }
  }

  async loginUser(req, res, next) {
    try{
      const data = req.body;
      const user = await userModel.findOne({_email: data.email});
      if(!user) {
        return res.status(404).send("User not found");
      }
  
     const comparePassword = await bcrypt.compare(data.password, user._password);

     if(!comparePassword){
        return res.status(401).send("Invalid credential");
     }
     
     const token = jwt.sign({ email: user._email }, 'secret');
      res.status(200).json({token})

    }catch(error){
        res.status(500).json({ error: 'Internal server error' });
    }
  }
}
