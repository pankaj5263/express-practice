import mongoose from "mongoose";
const Schema = mongoose.Schema;

const userSchema = new mongoose.Schema({
    _name: {
      type: String,
      required: true
    },
    _userId: {
      type: Number,
      required: true
    },
    _email:{
        type: String,
        required: true
    },
    _password:{
        type: String,
        required: true
    }
  });


const userModel = mongoose.model('user', userSchema);

export default userModel;