import express from 'express';
import AuthenticationController from './controller.js';
const router = express.Router();

const users = new  AuthenticationController();

router.post('/register', users.registerUser);
router.post('/login', users.loginUser);

export default router;