import express from 'express';
import TaskController from './controller.js';
const router = express.Router();

const task = new TaskController();
console.log("3333333333",JSON.stringify(task.getAllTasks));
router.get('/', task.getAllTasks);
router.post('/', task.createTask);
router.put('/:id', task.updateTaskById);
router.delete('/:id', task.deleteTaskById);
router.get('/filter', task.taskFilter)
export default router;