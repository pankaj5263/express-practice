import taskModel from "./modal.js";
export default class TaskController {
    async createTask(req, res){
        try{
            const newTask = {
                taskId: req.body.taskId,
                task: req.body.task,
                status: req.body.status
            }
            const task = new taskModel(newTask);
            task.save();
            res.status(200).send("Task created successfully");
        } catch(err){
            res.status(500).send("Task creation failed");
        }

    }
    async getAllTasks(req, res) {
        try{
            const tasks = await taskModel.find();
            res.status(200).json(tasks);
        }catch(err){
          res.status(400).send("Internal Server Error");
        }
    }
    async updateTaskById(req, res){
        try{
            const task = await taskModel.find({taskId:req.params.id});
            if(!task){
             return res.status(404).send("Task not found");
            }
            const update = await taskModel.findOneAndUpdate({taskId:req.params.id}, {task: req.body.task});

            if(!update){
             res.status(400).send("task updation failed");
            }
            update.save();
            return res.status(201).send("Successfully updated");
        } catch(err){
           res.status(500).send("internal server error");
        }

    }
    async deleteTaskById(req, res){
        try{
            const task = await taskModel.find({taskId:req.params.id});
            if(!task){
             return res.status(404).send("Task not found");
            }
            const update = await taskModel.findOneAndDelete({taskId:req.params.id});
            if(!update){
             res.status(400).send("task deletion failed");
            }
            update.save();
            return res.status(201).send("Successfully deleted");
        } catch(err){
           res.status(500).send("internal server error");
        }
    }

    async taskFilter(req, res){
        try{
            const task = await taskModel.find({status:req.query.status});
            if(!task){
             return res.status(404).send("Task not found");
            }
            return res.status(201).json(task);
        } catch(err){
           res.status(500).send("internal server error");
        }
    }
}     