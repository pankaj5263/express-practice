import mongoose from "mongoose";
import env from 'dotenv';
env.config();
const db = async function main() {
    try{
        await mongoose.connect('mongodb://localhost:27017/portal');
        console.log("DB connected");
    } catch(err){
        throw new Error("DB does not connected")
    }
  
}

export default db;